# AgentOS Launch Kit

This is a simple landing page + signup + Stripe-payment-link front-end for AgentOS.

## Files

- `site/index.html` — landing page, pricing and signup form.
- `site/styles.css` — responsive styling.
- `site/app.js` — Stripe Payment Link configuration and signup request.
- `README.md` — setup notes.

## Stripe

Create Stripe Payment Links for the Startup and Business plans, then put the URLs into:

```js
const CHECKOUT_LINKS = {
  startup: "https://buy.stripe.com/...",
  business: "https://buy.stripe.com/..."
};
```

Do NOT put Stripe secret API keys in browser code.

Payment Links are deliberately used here so card/payment handling stays on Stripe.

## FastAPI integration

The existing AgentOS FastAPI service needs to serve `/site` as static files and provide:

```http
POST /signup
Content-Type: application/json

{"email":"customer@example.com","company":"Example Inc"}
```

For a production account system, replace the starter signup endpoint with a proper authentication/database system. Do not store plaintext passwords.

## Production checklist

- Use a real domain.
- Configure Stripe products/prices and Payment Links.
- Use a production database rather than SQLite for multi-instance deployments.
- Add rate limiting and abuse protection.
- Add proper user authentication and password reset/SSO.
- Keep API secrets only in server-side secret storage.
