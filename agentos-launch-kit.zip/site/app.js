/*
  Replace the two URLs below with your Stripe Payment Links.
  Example:
  const CHECKOUT_LINKS = {
    startup: "https://buy.stripe.com/...",
    business: "https://buy.stripe.com/..."
  };
*/
const CHECKOUT_LINKS = {
  startup: "",
  business: ""
};

function startCheckout(plan) {
  const url = CHECKOUT_LINKS[plan];
  if (!url) {
    alert("Checkout is not configured yet. Add the Stripe Payment Link for this plan in site/app.js.");
    return;
  }
  window.location.href = url;
}

document.getElementById("signupForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = document.getElementById("signupMessage");
  const email = document.getElementById("email").value.trim();
  const company = document.getElementById("company").value.trim();

  message.textContent = "Creating your account...";

  try {
    const response = await fetch("/signup", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({email, company})
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.detail || "Signup failed.");
    }

    message.textContent = "Account request received. Check your email for the next step.";
    event.target.reset();
  } catch (error) {
    message.textContent = error.message || "Signup failed.";
  }
});
