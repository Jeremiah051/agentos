from app.sdk import AgentOS

gate = AgentOS("http://127.0.0.1:8000", "demo-agent-key")

print("READ:", gate.authorize(agent_id="demo-agent", action="crm.read", resource="customer", risk="low"))
print("EMAIL:", gate.authorize(agent_id="demo-agent", action="email.send", resource="customer", risk="high"))
print("PAYMENT:", gate.authorize(agent_id="demo-agent", action="payment.send", resource="invoice", amount=5000, risk="high"))
print("DELETE:", gate.authorize(agent_id="demo-agent", action="db.delete", resource="customers", risk="critical"))
