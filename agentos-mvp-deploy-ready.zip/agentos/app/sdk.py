from dataclasses import dataclass
from typing import Any
import requests

@dataclass
class AgentOS:
    base_url: str
    api_key: str
    timeout: float = 10.0

    def authorize(self, *, agent_id: str, action: str, resource: str, risk: str = "low", amount: float = 0, metadata: dict[str, Any] | None = None) -> dict:
        response = requests.post(
            f"{self.base_url.rstrip('/')}/v1/authorize",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"agent_id": agent_id, "action": action, "resource": resource, "risk": risk, "amount": amount, "metadata": metadata or {}},
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()

    def enforce(self, **kwargs) -> dict:
        result = self.authorize(**kwargs)
        if result["decision"] != "allow":
            raise PermissionError(f"AgentOS blocked action: {result['reason']} ({result['decision']})")
        return result
