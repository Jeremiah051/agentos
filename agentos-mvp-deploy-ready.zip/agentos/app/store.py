import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from .models import AuditEvent

DB_PATH = Path(__file__).resolve().parent.parent / "agentos.db"


def init_db() -> None:
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_events (
                request_id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                action TEXT NOT NULL,
                resource TEXT NOT NULL,
                risk TEXT NOT NULL,
                amount REAL NOT NULL,
                decision TEXT NOT NULL,
                reason TEXT NOT NULL,
                policy_id TEXT NOT NULL
            )
        """)
        conn.commit()


def write_event(event: AuditEvent) -> None:
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            INSERT INTO audit_events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (event.request_id, event.timestamp.isoformat(), event.agent_id, event.action,
               event.resource, event.risk, event.amount, event.decision, event.reason, event.policy_id))
        conn.commit()


def recent_events(limit: int = 50) -> list[dict]:
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM audit_events ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
    return [dict(r) for r in rows]
