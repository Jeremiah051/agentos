import os
import secrets
import uuid
from datetime import datetime, timezone
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from .models import AuthorizationRequest, AuthorizationResponse, AuditEvent
from .policy import evaluate
from .store import init_db, recent_events, write_event

API_KEY = os.getenv("AGENTOS_API_KEY", "demo-agent-key")
app = FastAPI(title="AgentOS", version="0.1.0", description="Authorization + audit gateway for AI-agent actions")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
def startup() -> None:
    init_db()


def auth(authorization: str | None = Header(default=None)) -> None:
    expected = f"Bearer {API_KEY}"
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="Invalid API key")

@app.get("/health")
def health() -> dict:
    return {"status": "ok", "service": "agentos", "version": "0.1.0"}

@app.post("/v1/authorize", response_model=AuthorizationResponse, dependencies=[Depends(auth)])
def authorize(req: AuthorizationRequest) -> AuthorizationResponse:
    decision = evaluate(req)
    request_id = str(uuid.uuid4())
    event = AuditEvent(
        request_id=request_id,
        timestamp=datetime.now(timezone.utc),
        agent_id=req.agent_id,
        action=req.action,
        resource=req.resource,
        risk=req.risk,
        amount=req.amount,
        decision=decision.decision,
        reason=decision.reason,
        policy_id=decision.policy_id,
    )
    write_event(event)
    return AuthorizationResponse(
        decision=decision.decision,
        reason=decision.reason,
        policy_id=decision.policy_id,
        request_id=request_id,
    )

@app.get("/v1/audit", dependencies=[Depends(auth)])
def audit(limit: int = Query(default=50, ge=1, le=200)) -> list[dict]:
    return recent_events(limit)
