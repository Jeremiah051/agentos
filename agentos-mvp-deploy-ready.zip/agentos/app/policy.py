from dataclasses import dataclass
from .models import AuthorizationRequest, Decision

@dataclass(frozen=True)
class PolicyDecision:
    decision: Decision
    reason: str
    policy_id: str

DESTRUCTIVE_ACTIONS = {
    "db.delete", "file.delete", "account.disable", "user.delete", "production.deploy_force"
}
FINANCIAL_ACTIONS = {"payment.send", "payment.refund", "payout.create", "purchase.create"}
HIGH_RISK_ACTIONS = {"email.send", "message.send", "code.execute", "production.deploy"}
READ_ACTIONS = {"db.read", "file.read", "crm.read", "calendar.read"}


def evaluate(req: AuthorizationRequest) -> PolicyDecision:
    if req.action in DESTRUCTIVE_ACTIONS or req.risk == "critical":
        return PolicyDecision("deny", "Destructive or critical actions are blocked by default.", "starter-v1")

    if req.action in FINANCIAL_ACTIONS:
        if req.amount > 1000:
            return PolicyDecision("approval_required", "Financial actions above $1,000 require human approval.", "starter-v1")
        return PolicyDecision("approval_required", "Financial actions require human approval.", "starter-v1")

    if req.action in HIGH_RISK_ACTIONS or req.risk == "high":
        return PolicyDecision("approval_required", "High-risk writes require human approval.", "starter-v1")

    if req.action in READ_ACTIONS or req.risk in {"low", "medium"}:
        return PolicyDecision("allow", "Action is within the starter least-privilege policy.", "starter-v1")

    return PolicyDecision("deny", "No matching policy rule; default deny.", "starter-v1")
