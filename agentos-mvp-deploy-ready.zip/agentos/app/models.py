from datetime import datetime, timezone
from typing import Any, Literal
from pydantic import BaseModel, Field

Decision = Literal["allow", "deny", "approval_required"]
Risk = Literal["low", "medium", "high", "critical"]

class AuthorizationRequest(BaseModel):
    agent_id: str = Field(min_length=1, max_length=200)
    action: str = Field(min_length=1, max_length=200)
    resource: str = Field(min_length=1, max_length=200)
    risk: Risk = "low"
    amount: float = Field(default=0, ge=0)
    metadata: dict[str, Any] = Field(default_factory=dict)

class AuthorizationResponse(BaseModel):
    decision: Decision
    reason: str
    policy_id: str
    request_id: str

class AuditEvent(BaseModel):
    request_id: str
    timestamp: datetime
    agent_id: str
    action: str
    resource: str
    risk: Risk
    amount: float
    decision: Decision
    reason: str
    policy_id: str
