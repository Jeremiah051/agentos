# AgentOS

AgentOS is a lightweight authorization and audit gateway for AI-agent tool calls.

## What it does

Every requested agent action is evaluated against policy and returns one of:

- `allow`
- `deny`
- `approval_required`

Every decision is written to an audit log.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs

Demo credentials are intentionally simple for local development:

```text
Authorization: Bearer demo-agent-key
```

## Core API

`POST /v1/authorize`

Example:

```json
{
  "agent_id": "support-agent",
  "action": "email.send",
  "resource": "customer",
  "risk": "high",
  "amount": 0,
  "metadata": {"recipient": "customer@example.com"}
}
```

The starter policy allows read-only actions, blocks destructive actions, and requires approval for high-risk writes or financial actions.

## Product direction

The long-term product is the policy/control plane for autonomous software: agent identity, delegated authority, least privilege, approvals, auditability, risk-based controls, and integrations.

This repository is an MVP—not a production security boundary. Before production use, replace the demo API key, use managed secrets, TLS, a durable database, tenant isolation, key rotation, rate limits, structured policy versioning, and an independently reviewed threat model.

## Deploy to Railway (recommended MVP path)

1. Push this repository to GitHub.
2. In Railway, create a new project from the GitHub repository.
3. Railway will use `railway.json` + `Dockerfile` and expose the service on its generated HTTPS domain.
4. Add environment variable `AGENTOS_API_KEY` with a long random value.
5. Deploy and open `/docs` and `/health` on the generated domain.

For the first paid beta, keep one tenant/customer per deployment or add proper tenant isolation before accepting sensitive customer data. Do not use the demo key in production.
