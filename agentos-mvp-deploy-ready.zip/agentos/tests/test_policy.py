from app.models import AuthorizationRequest
from app.policy import evaluate

def test_read_is_allowed():
    d = evaluate(AuthorizationRequest(agent_id="a", action="crm.read", resource="customer"))
    assert d.decision == "allow"

def test_high_risk_requires_approval():
    d = evaluate(AuthorizationRequest(agent_id="a", action="email.send", resource="customer", risk="high"))
    assert d.decision == "approval_required"

def test_destructive_denied():
    d = evaluate(AuthorizationRequest(agent_id="a", action="db.delete", resource="customers", risk="critical"))
    assert d.decision == "deny"

def test_money_requires_approval():
    d = evaluate(AuthorizationRequest(agent_id="a", action="payment.send", resource="invoice", amount=100))
    assert d.decision == "approval_required"
